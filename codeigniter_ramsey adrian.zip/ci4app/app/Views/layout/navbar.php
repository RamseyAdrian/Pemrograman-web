<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/style/style.css">
</head>

<nav>
    <div id="main-name">
        <a href="">
            <h2>Monitoring IOT - Ramsey Adrian</h2>
        </a>
    </div>
    <div id="nav-menu">
        <ul>
            <a href="/">
                <li>Home</li>
            </a>
            <a href="/pages/device">
                <li>Device</li>
            </a>
        </ul>
    </div>
</nav>